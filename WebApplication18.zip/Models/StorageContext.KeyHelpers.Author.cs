﻿using WebApplication18.Models;
using WebApplication18.Models;
using Microsoft.WindowsAzure.Storage.Table;
using BlueMarble.Shared.Azure.Storage.Table;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using System;

namespace WebApplication18.Models
{
	public partial class StorageContext
	{
		#region Key Helpers
		
        public string GetAuthorPartitionKey(Author Author)
        {
            return GetPartitionKey(Constants.StorageTableNames.Authors);
        }

        public string GetAuthorPartitionKey()
        {
            return GetPartitionKey(Constants.StorageTableNames.Authors);
        }

        public string GetAuthorRowKey(Author Author)
        {
            return GetRowKey();
        }

        public string GetAuthorRowKey()
        {
            return GetRowKey();
        }

		#endregion
	}
}