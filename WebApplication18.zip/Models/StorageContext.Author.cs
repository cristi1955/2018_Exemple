﻿using WebApplication18.Models;
using WebApplication18.Models;
using Microsoft.WindowsAzure.Storage.Table;
using BlueMarble.Shared.Azure.Storage.Table;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using System;

namespace WebApplication18.Models
{
	public partial class StorageContext
	{
		#region Services

		#region Constants

		internal partial class Constants
		{
			internal partial class StorageTableNames
			{
				public const string Authors = "authors"; 
			}

			internal partial class StoragePartitionNames
			{
				public const string Author = "author"; 
			}
		}

		#endregion

		#region Initialize Table

		[InitializeTable]
        public void InitializeAuthorTables()
        {
            Authors = CloudTableClient.GetTableReference(Constants.StorageTableNames.Authors);
            Authors.CreateIfNotExists();
        }

		public CloudTable Authors { get; set; }

		#endregion

		#region Data Access Methods

		public IQueryable<Author> GetAuthors()
        {
            var partitionKeyFilter = TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.NotEqual, string.Empty);

            var query = new TableQuery<Author>().Where(partitionKeyFilter);

            var collection = Authors.ExecuteQuery(query);

            return collection.AsQueryable();
        }

		public async Task<IQueryable<Author>> GetAuthorsAsync()
        {
            var partitionKeyFilter = TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.NotEqual, string.Empty);

            var query = new TableQuery<Author>().Where(partitionKeyFilter);

            var returnList = await ExecuteSegmentedQueryAsync<Author>(query);

            return returnList.AsQueryable();
        }

		public IQueryable<Author> GetAuthors(string PartitionKey)
        {
            var partitionKeyFilter = TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, PartitionKey);

            var query = new TableQuery<Author>().Where(partitionKeyFilter);

            var collection = Authors.ExecuteQuery(query);

            return collection.AsQueryable();
        }

		public async Task<IQueryable<Author>> GetAuthorsAsync(string PartitionKey)
        {
            var partitionKeyFilter = TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, PartitionKey);

            var query = new TableQuery<Author>().Where(partitionKeyFilter);

            var returnList = await ExecuteSegmentedQueryAsync<Author>(query);

            return returnList.AsQueryable();
        }

        public Author GetAuthor(string PartitionKey, string RowKey)
        {
            var partitionKeyFilter = TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, PartitionKey);
			var rowKeyFilter = TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.Equal, RowKey);

			var queryFilter = TableQuery.CombineFilters(partitionKeyFilter, TableOperators.And, rowKeyFilter);

            var query = new TableQuery<Author>().Where(queryFilter);

            var collection = Authors.ExecuteQuery(query);

            return collection.FirstOrDefault();
        }

        public async Task<Author> GetAuthorAsync(string PartitionKey, string RowKey)
        {
            var partitionKeyFilter = TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, PartitionKey);
			var rowKeyFilter = TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.Equal, RowKey);

			var queryFilter = TableQuery.CombineFilters(partitionKeyFilter, TableOperators.And, rowKeyFilter);

            var query = new TableQuery<Author>().Where(queryFilter);

            var returnList = await ExecuteSegmentedQueryAsync<Author>(query);

            return returnList.FirstOrDefault();
        }

        public void InsertAuthor(Author Author)
        {
            Author.PartitionKey = GetAuthorPartitionKey(Author);
			Author.RowKey = GetAuthorRowKey(Author);
			Author.PublicId = Author.GetPublicId();

            Insert<Author>(Author, Authors);
        }

        public async Task InsertAuthorAsync(Author Author)
        {
            Author.PartitionKey = GetAuthorPartitionKey(Author);
			Author.RowKey = GetAuthorRowKey(Author);
			Author.PublicId = Author.GetPublicId();

            await InsertAsync<Author>(Author, Authors);
        }

        public void InsertAuthorBatch(IEnumerable<Author> Authors)
        {
            InsertBatch<Author>(Authors, this.Authors);
        }

        public async Task InsertAuthorBatchAsync(IEnumerable<Author> Authors)
        {
            await InsertBatchAsync<Author>(Authors, this.Authors);
        }

        public void UpdateAuthor(Author Author)
        {
            Replace<Author>(Author, Authors);
        }

        public async Task UpdateAuthorAsync(Author Author)
        {
            await ReplaceAsync<Author>(Author, Authors);
        }

        public void DeleteAuthor(Author Author)
        {
            Delete<Author>(Author, Authors);
        }

        public async Task DeleteAuthorAsync(Author Author)
        {
            await DeleteAsync<Author>(Author, Authors);
        }

		#endregion

        #endregion
	}
}