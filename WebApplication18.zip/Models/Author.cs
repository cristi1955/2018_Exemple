﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication18.Models
{
    public class Author : BlueMarble.Shared.Azure.Storage.Table.Entity
    {
        public Author() : base() { }
        public Author(string publicId) : base(publicId) { }

        public string Name { get; set; }
    }
}