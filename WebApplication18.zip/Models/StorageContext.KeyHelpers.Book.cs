﻿using WebApplication18.Models;
using WebApplication18.Models;
using Microsoft.WindowsAzure.Storage.Table;
using BlueMarble.Shared.Azure.Storage.Table;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using System;

namespace WebApplication18.Models
{
	public partial class StorageContext
	{
		#region Key Helpers
		
        public string GetBookPartitionKey(Book Book)
        {
            return GetPartitionKey(Constants.StorageTableNames.Books);
        }

        public string GetBookPartitionKey()
        {
            return GetPartitionKey(Constants.StorageTableNames.Books);
        }

        public string GetBookRowKey(Book Book)
        {
            return GetRowKey();
        }

        public string GetBookRowKey()
        {
            return GetRowKey();
        }

		#endregion
	}
}