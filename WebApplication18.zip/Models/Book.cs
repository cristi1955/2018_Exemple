﻿using BlueMarble.Shared.Azure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication18.Models
{
    public class Book : BlueMarble.Shared.Azure.Storage.Table.Entity
    {
        public Book() : base() { }
        public Book(string publicId) : base(publicId) { }

        public string Name { get; set; }

        [RelatedTable(Type = typeof(WebApplication18.Models.Author))]
        public string AuthorPublicId { get; set; }
    }
}