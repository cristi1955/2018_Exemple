﻿using WebApplication18.Models;
using WebApplication18.Models;
using Microsoft.WindowsAzure.Storage.Table;
using BlueMarble.Shared.Azure.Storage.Table;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using System;

namespace WebApplication18.Models
{
	public partial class StorageContext
	{
		#region Services

		#region Constants

		internal partial class Constants
		{
			internal partial class StorageTableNames
			{
				public const string Books = "books"; 
			}

			internal partial class StoragePartitionNames
			{
				public const string Book = "book"; 
			}
		}

		#endregion

		#region Initialize Table

		[InitializeTable]
        public void InitializeBookTables()
        {
            Books = CloudTableClient.GetTableReference(Constants.StorageTableNames.Books);
            Books.CreateIfNotExists();
        }

		public CloudTable Books { get; set; }

		#endregion

		#region Data Access Methods

		public IQueryable<Book> GetBooks()
        {
            var partitionKeyFilter = TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.NotEqual, string.Empty);

            var query = new TableQuery<Book>().Where(partitionKeyFilter);

            var collection = Books.ExecuteQuery(query);

            return collection.AsQueryable();
        }

		public async Task<IQueryable<Book>> GetBooksAsync()
        {
            var partitionKeyFilter = TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.NotEqual, string.Empty);

            var query = new TableQuery<Book>().Where(partitionKeyFilter);

            var returnList = await ExecuteSegmentedQueryAsync<Book>(query);

            return returnList.AsQueryable();
        }

		public IQueryable<Book> GetBooks(string PartitionKey)
        {
            var partitionKeyFilter = TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, PartitionKey);

            var query = new TableQuery<Book>().Where(partitionKeyFilter);

            var collection = Books.ExecuteQuery(query);

            return collection.AsQueryable();
        }

		public async Task<IQueryable<Book>> GetBooksAsync(string PartitionKey)
        {
            var partitionKeyFilter = TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, PartitionKey);

            var query = new TableQuery<Book>().Where(partitionKeyFilter);

            var returnList = await ExecuteSegmentedQueryAsync<Book>(query);

            return returnList.AsQueryable();
        }

        public Book GetBook(string PartitionKey, string RowKey)
        {
            var partitionKeyFilter = TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, PartitionKey);
			var rowKeyFilter = TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.Equal, RowKey);

			var queryFilter = TableQuery.CombineFilters(partitionKeyFilter, TableOperators.And, rowKeyFilter);

            var query = new TableQuery<Book>().Where(queryFilter);

            var collection = Books.ExecuteQuery(query);

            return collection.FirstOrDefault();
        }

        public async Task<Book> GetBookAsync(string PartitionKey, string RowKey)
        {
            var partitionKeyFilter = TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, PartitionKey);
			var rowKeyFilter = TableQuery.GenerateFilterCondition("RowKey", QueryComparisons.Equal, RowKey);

			var queryFilter = TableQuery.CombineFilters(partitionKeyFilter, TableOperators.And, rowKeyFilter);

            var query = new TableQuery<Book>().Where(queryFilter);

            var returnList = await ExecuteSegmentedQueryAsync<Book>(query);

            return returnList.FirstOrDefault();
        }

        public void InsertBook(Book Book)
        {
            Book.PartitionKey = GetBookPartitionKey(Book);
			Book.RowKey = GetBookRowKey(Book);
			Book.PublicId = Book.GetPublicId();

            Insert<Book>(Book, Books);
        }

        public async Task InsertBookAsync(Book Book)
        {
            Book.PartitionKey = GetBookPartitionKey(Book);
			Book.RowKey = GetBookRowKey(Book);
			Book.PublicId = Book.GetPublicId();

            await InsertAsync<Book>(Book, Books);
        }

        public void InsertBookBatch(IEnumerable<Book> Books)
        {
            InsertBatch<Book>(Books, this.Books);
        }

        public async Task InsertBookBatchAsync(IEnumerable<Book> Books)
        {
            await InsertBatchAsync<Book>(Books, this.Books);
        }

        public void UpdateBook(Book Book)
        {
            Replace<Book>(Book, Books);
        }

        public async Task UpdateBookAsync(Book Book)
        {
            await ReplaceAsync<Book>(Book, Books);
        }

        public void DeleteBook(Book Book)
        {
            Delete<Book>(Book, Books);
        }

        public async Task DeleteBookAsync(Book Book)
        {
            await DeleteAsync<Book>(Book, Books);
        }

		#endregion

        #endregion
	}
}