﻿using System.Web.Http;
using WebApplication18.Models;
using WebApplication18.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace WebApplication18.Controllers.Api
{
	public class BookController: ApiController
	{
		protected StorageContext db = new StorageContext();

		[HttpGet]
		public async Task<IEnumerable<Book>> Get()
		{
			return db.GetBooks();
		}

		[HttpGet]
		public async Task<Book> Get(string id)
		{
			var privateEntity = BlueMarble.Shared.Azure.Storage.Table.Entity.GetPrivateEntity(new Book(id));

			return db.GetBook(privateEntity.PartitionKey, privateEntity.RowKey).GetPublicEntity<Book>();
		}

		[HttpPost]
		public string Post(Book entity)
		{
			if (ModelState.IsValid)
			{
				db.InsertBook(entity);

				entity.PublicId = entity.GetPublicId();
				return entity.GetPublicEntity<Book>().PublicId;
			}

            return string.Empty;
		}

		[HttpPut]
		public void Put(string id, Book entity)
		{
			if (ModelState.IsValid)
			{
				db.UpdateBook(entity.GetPrivateEntity<Book>());
			}
		}

		[HttpDelete]
		public async Task Delete(string id)
		{
			var privateEntity = BlueMarble.Shared.Azure.Storage.Table.Entity.GetPrivateEntity(new Book() { PublicId = id });

			var entity = db.GetBook(privateEntity.PartitionKey, privateEntity.RowKey);
			
            if (entity == null)
                throw new System.Exception("Book entity not found, delete failed.");

			await db.DeleteBookAsync(entity);
		}

		protected override void Dispose(bool disposing)
        {
            db.Dispose(disposing);
            base.Dispose(disposing);
        }
	}
}