﻿using System.Web.Http;
using WebApplication18.Models;
using WebApplication18.Models;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;

namespace WebApplication18.Controllers.Api
{
	public class AuthorController: ApiController
	{
		protected StorageContext db = new StorageContext();

		[HttpGet]
		public async Task<IEnumerable<Author>> Get()
		{
			return db.GetAuthors();
		}

		[HttpGet]
		public async Task<Author> Get(string id)
		{
			var privateEntity = BlueMarble.Shared.Azure.Storage.Table.Entity.GetPrivateEntity(new Author(id));

			return db.GetAuthor(privateEntity.PartitionKey, privateEntity.RowKey).GetPublicEntity<Author>();
		}

		[HttpPost]
		public string Post(Author entity)
		{
			if (ModelState.IsValid)
			{
				db.InsertAuthor(entity);

				entity.PublicId = entity.GetPublicId();
				return entity.GetPublicEntity<Author>().PublicId;
			}

            return string.Empty;
		}

		[HttpPut]
		public void Put(string id, Author entity)
		{
			if (ModelState.IsValid)
			{
				db.UpdateAuthor(entity.GetPrivateEntity<Author>());
			}
		}

		[HttpDelete]
		public async Task Delete(string id)
		{
			var privateEntity = BlueMarble.Shared.Azure.Storage.Table.Entity.GetPrivateEntity(new Author() { PublicId = id });

			var entity = db.GetAuthor(privateEntity.PartitionKey, privateEntity.RowKey);
			
            if (entity == null)
                throw new System.Exception("Author entity not found, delete failed.");

			await db.DeleteAuthorAsync(entity);
		}

		protected override void Dispose(bool disposing)
        {
            db.Dispose(disposing);
            base.Dispose(disposing);
        }
	}
}