﻿/* *************************************** */
/* Book api data access */
/* *************************************** */

var BookData = BookData || (function(){
    

	return {
		PublicId: 'NOTSET',
		Delete: function(e) {

			var that = this;

			e.preventDefault();

            $.ajax({
                url: '/api/Book/' + that.PublicId,
                type: 'DELETE',
                dataType: 'json',
                success: function(data) {

                    window.location.href = '/Book/';

                },
                error: function(error) {

                    that.LogError(error);

                }
            });

		},
		Update: function(e) {

			var that = this;

		    e.preventDefault();

			$.ajax({
				url: '/api/Book/' + that.PublicId,
				type: 'PUT',
				dataType: 'json',
				data: {
					Name: that.Name,
					AuthorPublicId: that.AuthorPublicId,
					PublicId: this.PublicId
				},
				success: function(data) {

					window.location.href = '/Book/Edit/' + that.PublicId;

				},
				error: function(error) {

					that.LogError(error);

				}
			});

		},
		Create: function(e) {

			var that = this;

			e.preventDefault();

			$.ajax({
				url: '/api/Book',
				type: 'POST',
				dataType: 'json',
				data: {
					Name: that.Name,
					AuthorPublicId: that.AuthorPublicId,
					PublicId: that.PublicId
				},
				success: function(data) {

					window.location.href = '/Book/Details/' + data;

				},
				error: function(error) {

					that.LogError(error);

				}
			});

		},
		Load: function (form) {

			var that = this;

			that.ViewModel.loading = true;
			that.ViewModel.loaded = false;

			that.Bind(form);

			$.ajax({
				url: '/api/Book/' + that.PublicId,
				type: 'GET',
				dataType: 'json',
				success: function (data) {

					that.LoadEntity(data, form);

				},
				error: function (error) {

					that.LogError(error);

				}
			});

		},
		LoadEntity: function(data, form){

			var that = this;
			that.ViewModel.Name = data.Name;
			that.ViewModel.AuthorPublicId = data.AuthorPublicId;
			that.ViewModel.PublicId = data.PublicId;

			$.ajax({
				url: '/api/Author/' + that.ViewModel.AuthorPublicId,
				type: 'GET',
				dataType: 'json',
				success: function (data) {

					that.ViewModel.AuthorPublicId_Display = data.Name;

				},
				error: function (error) {

					that.ViewModel.AuthorPublicId_Display = 'error reading data';

					console.log(error);
					    
				}
			}).done(function (data) {

		        that.Bind(form);

		    });

			that.ViewModel.loading = false;
			that.ViewModel.loaded = true;

			that.Bind(form);

		},
		ViewModel: kendo.observable({
			PublicId: '',
			AuthorsDataSource: null,
		
			Name: '',
			AuthorPublicId: '',
			AuthorPublicId_Display: 'loading...',
			hasChanges: false,
			saving: false,
			saved: false,
			creating: false,
			created: false,
			deleting: false,
			deleted: false,
			loading: true,
			loaded: false,
			error: false,
			errorMessage: '',
			update: undefined,
			delete: undefined,
			create: undefined
				
		}),
		Bind: function(form) {

		    kendo.bind(form, this.ViewModel);

		},
		LogError: function(error) {

			var that = this;
			
			that.ViewModel.error = true;
			that.ViewModel.errorMessage = error.responseJSON.ExceptionMessage;

			console.log(error);

		},
		Init: function(publicId) {
			
			var that = this;

		    that.PublicId = publicId;

			that.ViewModel.PublicId = publicId;

			that.ViewModel.AuthorsDataSource = AuthorsData.AuthorsDataSource;
			that.ViewModel.Name = '';
			that.ViewModel.AuthorPublicId = '';
			that.ViewModel.AuthorPublicId_Display = 'loading...';
				
			that.ViewModel.update = that.Update;
			that.ViewModel.delete = that.Delete;
			that.ViewModel.create = that.Create;
		}
	};
}());
