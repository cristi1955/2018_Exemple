﻿/* *************************************** */
/* Author api data access */
/* *************************************** */

var AuthorsData = AuthorsData || (function(){

	return {
		AuthorsDataSource: new kendo.data.DataSource({
			transport: {

				read: {
					url: '/api/Author',
					dataType: 'json'
				}
			
			},
			schema: {

				model: {
					Name: 'Name',
				}

			}
		})

	};
}());
