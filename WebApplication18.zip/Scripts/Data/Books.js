﻿/* *************************************** */
/* Book api data access */
/* *************************************** */

var BooksData = BooksData || (function(){

	return {
		BooksDataSource: new kendo.data.DataSource({
			transport: {

				read: {
					url: '/api/Book',
					dataType: 'json'
				}
			
			},
			schema: {

				model: {
					Name: 'Name',
					AuthorPublicId: 'AuthorPublicId',
				}

			}
		})

	};
}());
