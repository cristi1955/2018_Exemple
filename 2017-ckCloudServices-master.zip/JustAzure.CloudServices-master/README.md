JustAzure.CloudServices
=======================

This repository contains the samples for the Microsoft Azure Cloud Services series on JustAzure.com
