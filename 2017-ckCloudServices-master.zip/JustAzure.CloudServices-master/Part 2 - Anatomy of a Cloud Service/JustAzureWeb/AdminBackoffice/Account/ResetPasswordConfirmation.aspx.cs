﻿using System.Web.UI;

namespace AdminBackoffice.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}