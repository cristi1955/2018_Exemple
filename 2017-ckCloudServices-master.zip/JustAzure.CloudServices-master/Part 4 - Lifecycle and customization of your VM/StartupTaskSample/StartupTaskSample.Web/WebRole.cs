using Microsoft.WindowsAzure.ServiceRuntime;

namespace StartupTaskSample.Web
{
    public class WebRole : RoleEntryPoint
    {
        public override bool OnStart()
        {
            return base.OnStart();
        }
    }
}
